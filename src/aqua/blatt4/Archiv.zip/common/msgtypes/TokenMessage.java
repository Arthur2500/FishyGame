package aqua.blatt4.common.msgtypes;

import java.io.Serializable;

public class TokenMessage implements Serializable {}