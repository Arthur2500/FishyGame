// TankModel.java – final überarbeitete Snapshot-Logik (mehrere Snapshots nacheinander möglich)

package aqua.blatt4.client;

import java.net.InetSocketAddress;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import aqua.blatt1.common.Direction;
import aqua.blatt1.common.FishModel;
import aqua.blatt4.common.msgtypes.TokenMessage;
import aqua.blatt4.common.msgtypes.SnapshotMarker;
import aqua.blatt4.common.msgtypes.SnapshotTokenMessage;

public class TankModel extends Observable implements Iterable<FishModel> {
    public static final int WIDTH = 600;
    public static final int HEIGHT = 350;
    private static final int MAX_FISHIES = 5;
    private static final Random rand = new Random();

    private final Set<FishModel> fishies;
    private final ClientCommunicator.ClientForwarder forwarder;

    private volatile String id;
    private int fishCounter = 0;

    private InetSocketAddress leftNeighbor;
    private InetSocketAddress rightNeighbor;

    private boolean hasToken;
    private Timer tokenTimer;

    private boolean isSnapshotInitiator = false;
    private SnapshotTokenMessage pendingSnapshotToken;
    private int localSnapshot;
    private final List<FishModel> leftChannelBuffer = Collections.synchronizedList(new ArrayList<>());
    private final List<FishModel> rightChannelBuffer = Collections.synchronizedList(new ArrayList<>());
    private boolean markerReceivedFromLeft = false;
    private boolean markerReceivedFromRight = false;
    private boolean snapshotActive = false;
    private boolean localSnapshotCounted = false;

    public TankModel(ClientCommunicator communicator) {
        this.fishies = Collections.newSetFromMap(new ConcurrentHashMap<>());
        this.forwarder = communicator.newClientForwarder(this);
    }

    public void onRegistration(String id) {
        this.id = id;
        newFish(WIDTH - FishModel.getXSize(), rand.nextInt(HEIGHT - FishModel.getYSize()));
    }

    public synchronized void newFish(int x, int y) {
        if (fishies.size() < MAX_FISHIES) {
            x = Math.min(x, WIDTH - FishModel.getXSize() - 1);
            y = Math.min(y, HEIGHT - FishModel.getYSize());
            FishModel fish = new FishModel("fish" + (++fishCounter) + "@" + getId(), x, y,
                    rand.nextBoolean() ? Direction.LEFT : Direction.RIGHT);
            fishies.add(fish);
        }
    }

    public synchronized void initiateSnapshot() {
        if (snapshotActive || pendingSnapshotToken != null) {
            System.out.println("[Snapshot] Already active, ignoring request.");
            return;
        }

        snapshotActive = true;
        isSnapshotInitiator = true;
        localSnapshot = fishies.size();
        leftChannelBuffer.clear();
        rightChannelBuffer.clear();
        markerReceivedFromLeft = false;
        markerReceivedFromRight = false;

        forwarder.sendSnapshotMarker();
        pendingSnapshotToken = new SnapshotTokenMessage(id, localSnapshot);

        System.out.println("[Snapshot] Initiated by " + id);
    }

    public synchronized void onSnapshotMarker(InetSocketAddress sender) {
        boolean fromLeft = sender.equals(leftNeighbor);
        System.out.println("[Marker] Received from " + sender);

        if (!snapshotActive) {
            snapshotActive = true;
            localSnapshot = fishies.size();
            leftChannelBuffer.clear();
            rightChannelBuffer.clear();
            markerReceivedFromLeft = fromLeft;
            markerReceivedFromRight = !fromLeft;
            forwarder.sendSnapshotMarker();
        } else {
            if (fromLeft) markerReceivedFromLeft = true;
            else markerReceivedFromRight = true;
        }

        if (markerReceivedFromLeft && markerReceivedFromRight) {
            finishLocalSnapshot();
        }
    }

    private synchronized void finishLocalSnapshot() {
        System.out.println("[Snapshot] Finished by " + id);

        localSnapshot += leftChannelBuffer.size() + rightChannelBuffer.size();
        localSnapshotCounted = true; // wir haben es hinzugefügt

        for (FishModel f : leftChannelBuffer)  { f.setToStart(); fishies.add(f); }
        for (FishModel f : rightChannelBuffer) { f.setToStart(); fishies.add(f); }

        leftChannelBuffer.clear();
        rightChannelBuffer.clear();

        if (pendingSnapshotToken != null) {
            int sum = pendingSnapshotToken.getSum() + localSnapshot;
            if (pendingSnapshotToken.getInitiatorId().equals(id)) {
                JOptionPane.showMessageDialog(null,
                        "🐟 Global Snapshot abgeschlossen!\n\nGesamtanzahl aller Fische: " + sum,
                        "Global Snapshot", JOptionPane.INFORMATION_MESSAGE);
            } else {
                forwarder.sendSnapshotToken(new SnapshotTokenMessage(
                        pendingSnapshotToken.getInitiatorId(), sum));
            }

            resetSnapshotState();
        } else {
            System.out.println("[Snapshot] Local snapshot complete. Waiting for token.");
        }
    }

    private synchronized void resetSnapshotState() {
        snapshotActive = false;
        markerReceivedFromLeft = false;
        markerReceivedFromRight = false;
        pendingSnapshotToken = null;
        isSnapshotInitiator = false;
        localSnapshotCounted = false;
    }

    public synchronized void receiveFish(InetSocketAddress sender, FishModel fish) {
        boolean fromLeft = sender.equals(leftNeighbor);

        if (snapshotActive) {
            if (!markerReceivedFromLeft && fromLeft) {
                leftChannelBuffer.add(fish); return;
            } else if (!markerReceivedFromRight && !fromLeft) {
                rightChannelBuffer.add(fish); return;
            }
        }

        fish.setToStart();
        fishies.add(fish);
    }

    public synchronized void onSnapshotToken(SnapshotTokenMessage token) {
        System.out.println("[Token] Received: " + token.getSum() + " from " + token.getInitiatorId());

        if (snapshotActive) {
            pendingSnapshotToken = token;
            return;
        }

        int updatedSum = token.getSum();
        if (!localSnapshotCounted) {
            updatedSum += localSnapshot;
            localSnapshotCounted = true;
        }

        if (token.getInitiatorId().equals(id)) {
            JOptionPane.showMessageDialog(null,
                    "🐟 Global Snapshot abgeschlossen!\n\nGesamtanzahl aller Fische: " + updatedSum,
                    "Global Snapshot", JOptionPane.INFORMATION_MESSAGE);
            resetSnapshotState();
        } else {
            forwarder.sendSnapshotToken(new SnapshotTokenMessage(token.getInitiatorId(), updatedSum));
        }
    }

    public synchronized void receiveToken() {
        this.hasToken = true;
        setChanged(); notifyObservers();
        tokenTimer = new Timer();
        tokenTimer.schedule(new TimerTask() {
            @Override public void run() {
                hasToken = false;
                sendToken();
                setChanged(); notifyObservers();
            }
        }, 2000);
    }

    private synchronized void sendToken() {
        forwarder.sendRingToken();
    }

    public boolean hasToken() { return hasToken; }
    public void setNeighbors(InetSocketAddress left, InetSocketAddress right) {
        this.leftNeighbor = left;
        this.rightNeighbor = right;
    }
    public InetSocketAddress getLeftNeighbor() { return leftNeighbor; }
    public InetSocketAddress getRightNeighbor() { return rightNeighbor; }
    public String getId() { return id; }
    public synchronized int getFishCounter() { return fishCounter; }
    @Override
    public synchronized Iterator<FishModel> iterator() {
        return fishies.iterator();
    }

    private synchronized void updateFishies() {
        for (Iterator<FishModel> it = iterator(); it.hasNext();) {
            FishModel fish = it.next();
            fish.update();
            if (fish.hitsEdge()) {
                if (hasToken) {
                    forwarder.handOff(fish);
                    it.remove();
                } else {
                    fish.reverse();
                }
            }
            if (fish.disappears()) it.remove();
        }
    }

    private synchronized void update() {
        updateFishies();
        setChanged(); notifyObservers();
    }

    public void run() {
        forwarder.register();
        try {
            while (!Thread.currentThread().isInterrupted()) {
                update();
                TimeUnit.MILLISECONDS.sleep(10);
            }
        } catch (InterruptedException ignored) {}
    }

    public synchronized void finish() {
        forwarder.deregister(id);
    }
}